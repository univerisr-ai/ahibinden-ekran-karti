import os
import sys
import time
import json
import random
import asyncio
from pathlib import Path
from pyvirtualdisplay import Display
import nodriver as uc
import requests
from dotenv import load_dotenv

load_dotenv()

TARGET_URL = os.getenv("TARGET_URL", "https://www.sahibinden.com/ekran-karti-masaustu")
COOKIE_FILE = Path(__file__).parent / "cookies.json"
TELEGRAM_BOT_TOKEN_1 = os.getenv("TELEGRAM_BOT_TOKEN_1")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

def send_cookie_to_telegram(cookie_dict, ua):
    if not TELEGRAM_BOT_TOKEN_1 or not TELEGRAM_CHAT_ID:
        print("[-] Telegram ayarları (.env) eksik. Cookie Telegram'a gönderilemedi.")
        return
        
    cookie_str = "; ".join([f"{k}={v}" for k, v in cookie_dict.items()])
    
    if "cf_clearance" not in cookie_dict:
        message = (
            "⚠️ [HATA: TESPİT EDİLDİ]\n\n"
            "Sistem Cloudflare engelini aşamadı (`cf_clearance` yok).\n"
            "Mevcut durumun ekran görüntüsü ektedir."
        )
    else:
        message = (
            "🟢 [YENI_COOKIE_KOMUTU]\n\n"
            "Sistem taptaze bir Cloudflare çerezi üretti!\n\n"
            f"🍪 **Cookie:**\n`{cookie_str}`\n\n"
            f"🕵️ **User-Agent:**\n`{ua}`"
        )
    
    try:
        photo_path = Path(__file__).parent / "debug.png"
        if photo_path.exists():
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN_1}/sendPhoto"
            with open(photo_path, "rb") as photo:
                resp = requests.post(url, data={"chat_id": TELEGRAM_CHAT_ID, "caption": message, "parse_mode": "Markdown"}, files={"photo": photo})
        else:
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN_1}/sendMessage"
            resp = requests.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "Markdown"})
            
        if resp.status_code == 200:
            print("[+] Cookie/Mesaj başarıyla Telegram'a iletildi!")
        else:
            print(f"[-] Telegram gönderim hatası: HTTP {resp.status_code} - {resp.text}")
    except Exception as e:
        print(f"[-] Telegram istek hatası: {e}")

async def bypass_cloudflare_and_get_cookies():
    print("[*] 1. Sanal Ekran (Xvfb) Başlatılıyor...")
    # Headless: False yapabilmek ve Google Cloud'da çalışabilmek için sanal ekran açıyoruz
    display = Display(visible=0, size=(1920, 1080))
    display.start()
    
    browser = None
    try:
        print("[*] 2. Nodriver ile undetected Chrome başlatılıyor...")
        # Tarayıcıyı headless DEĞİL (yani görünür) başlatıyoruz (Xvfb içine açılacak).
        # Bu sayede Cloudflare'in "bot" işaretlerini tetikleme ihtimali düşüyor.
        browser = await uc.start(headless=False, browser_args=['--no-sandbox', '--disable-setuid-sandbox'])
        
        print(f"[*] {TARGET_URL} Adresine Gidiliyor...")
        page = await browser.get(TARGET_URL)
        
        # İnsan simülasyonu: Rastgele bekleme (Fitts Kanunu / Human-in-the-loop simülasyonu)
        await asyncio.sleep(random.uniform(4.5, 7.5))
        
        # Cloudflare kontrolünü geçmeyi bekle (Gerekirse Turnstile beklemesi)
        print("[*] Cloudflare Sayfasının Geçilmesi Bekleniyor (Maksimum 45sn)...")
        passed = False
        for i in range(15):
            content = await page.get_content()
            if "just a moment" not in content.lower() and "challenge-platform" not in content.lower():
                print("[+] Cloudflare Kontrolü Başarıyla Geçildi!")
                passed = True
                break
            print(f"  ... {i * 3} saniye geçti, Turnstile bekleniyor...")
            await asyncio.sleep(3)
        
        if not passed:
            print("[-] Uyarı: Cloudflare bekleme süresi doldu, sayfa tam yüklenmemiş olabilir.")
            
        print("[*] Çerezler (Cookies) Toplanıyor...")
        await asyncio.sleep(3)  # Çerezlerin oturması için son bekleme
        
        # Ekran görüntüsü al (Hata ayıklamak için)
        try:
            await page.save_screenshot(str(Path(__file__).parent / "debug.png"))
            print("[+] Ekran görüntüsü (debug.png) kaydedildi.")
        except Exception as e:
            print(f"[-] Ekran görüntüsü alınamadı: {e}")
            
        # Çerezleri Nodriver üzerinden çek
        cookies_list = await browser.cookies.get_all()
        cookie_dict = {c.name: c.value for c in cookies_list}
        
        # User-Agent'ı çek
        ua = await page.evaluate("navigator.userAgent")
        
        # Eğer critical clearance yoksa uyar
        if "cf_clearance" not in cookie_dict:
            print("[-] DİKKAT: 'cf_clearance' çerezi alınamadı. İstekler 403 Forbidden yiyebilir.")
        else:
            print("[+] 'cf_clearance' başarıyla alındı!")
            
        # JSON Olarak Kaydet (fast_scraper.py buradan okuyacak)
        output_data = {
            "cookies": cookie_dict,
            "user_agent": ua,
            "timestamp": time.time()
        }
        
        with open(COOKIE_FILE, "w", encoding="utf-8") as f:
            json.dump(output_data, f, indent=4)
            
        print(f"[+] Çerezler {COOKIE_FILE.name} dosyasına kaydedildi.")
        
        # Kullanıcının zincirleme otomasyon planı: Veriyi anında Telegram botuna ileterek tetikle
        send_cookie_to_telegram(cookie_dict, ua)
        
        if "cf_clearance" not in cookie_dict:
            return False
            
        return True
        
    except Exception as e:
        print(f"[-] Hata Oluştu (cookie_generator): {e}")
        return False
        
    finally:
        if browser:
            print("[*] Chrome kapatılıyor...")
            browser.stop()
        if display:
            print("[*] Sanal Ekran (Xvfb) Kapatılıyor...")
            display.stop()

def main():
    print("=========================================")
    print("   Sahibinden Cookie Generator (v1)")
    print("   Nodriver + Xvfb (Cloudflare Bypass)")
    print("=========================================")
    
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        success = loop.run_until_complete(bypass_cloudflare_and_get_cookies())
        if not success:
            os._exit(1)
        os._exit(0)
    except Exception as e:
        print(f"[-] Kritik Hata: {e}")
        os._exit(1)

if __name__ == "__main__":
    main()
